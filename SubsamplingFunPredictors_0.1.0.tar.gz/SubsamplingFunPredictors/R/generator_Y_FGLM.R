# function of generate Y
#' @title The function to generate the sample of response variable
#' @description The function to generate the sample of response variable.
#' @param n The number of observation.
#' @param prob The n x 1 vector, the \emph{i}th element is the probability
#' of success on the\emph{i}th trial (family = "Binomial)
#' or the mean of \emph{i}th observation (family = "Possion").
#' @param family A description of the distribution of the response variable.
#' @return The n x 1 vector of the generated response.

generator_Y_FGLM = function(n,prob,family)
{
  if(family == "Binomial"){Y = rbinom(n = n, prob = prob, size = 1)}
  else if (family == "Possion") {Y = rpois(n = n, lambda = prob)}
  else {print("family does not exit")}
  return(Y)
}
