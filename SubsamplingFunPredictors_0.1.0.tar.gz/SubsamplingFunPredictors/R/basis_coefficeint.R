#' function to generate the coefficient of basis
#'
#'
#' @param n The nubmer of observations of the generated data.
#' @param nbasis The number of basis to generate the data X.
#' @param ii The index of the setting of the coefficient of basis, e.g. the coefficient of basis if from a standard normal distribution.
#' @param a Please see the details.
#' @param b Please see the details.
#' @param df The degree of t distribution.
#' @details The table of the different distributions associated with the index ii:
#' \tabular{rl}{
#'
#'ii=1 \tab \eqn{a~N(a,b)}   \cr
#'ii=2 \tab \eqn{a~t_{df}(a,b)} \cr
#'ii=3 \tab \eqn{a~U[a,b]}    \cr
#'}

#' @return The n x nbasis matrix of generated coefficient of basis.
a_fun = function(n,nbasis, ii,a,b,df)
{
  if(ii == 1) {a = matrix(rnorm(nbasis*n,a,b),n,nbasis)}
  else if(ii == 2) {a = matrix(rmt(nbasis*n,mean = rep(a,1),b,df=df),n,nbasis)}
  else if(ii == 3) {a = matrix(runif(nbasis*n,a,b),n,nbasis)}
  else{print("model does not exit")}
  return(a)
}



