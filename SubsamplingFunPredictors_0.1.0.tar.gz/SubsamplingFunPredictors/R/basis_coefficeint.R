#' function to generate the coefficient of basis
#'
#'
#' @param n The nubmer of observations of the generated data.
#' @param nbasis The number of basis to generate the data X.
#' @param ii The index of the setting of the coefficient of basis, e.g. the coefficient of basis if from a standard normal distribution.
#' @details The table of the different distributions associated with the index ii:
#' \tabular{rl}{
#'
#'ii=1 \tab \eqn{a~N(0,1)}   \cr
#'ii=2 \tab \eqn{a~t_3(0,1)} \cr
#'ii=3 \tab \eqn{a~t_2(0,1)}    \cr
#'ii=4 \tab \eqn{a~N(1,5)}    \cr
#'ii=5 \tab \eqn{a~N(0,10)}   \cr
#'ii=6 \tab \eqn{a~U(0,4)} \cr
#'ii=7 \tab \eqn{a~N(1.5,2)} \cr
#'ii=8 \tab \eqn{a~t_4(0,1)} \cr
#'ii=9 \tab \eqn{a~U(-4,4)} \cr
#'ii=10 \tab \eqn{a~N(0,6)} \cr
#'ii=11 \tab \eqn{a~N(1.5,15)} \cr
#'ii=12 \tab \eqn{a~N(0,15)} \cr
#'ii=13 \tab \eqn{a~t_2(0,10)} \cr
#'
#'}

#' @return The n x nbasis matrix of generated coefficient of basis.
a_fun = function(n,nbasis, ii)
{
  #sigma = 2*0.5^(toeplitz(0:(n-1)))
  if(ii == 1) {a = matrix(rnorm(nbasis*n,0,1),n,nbasis)}
  else if(ii == 2) {a = matrix(rmt(nbasis*n,mean = rep(0,1),1,df=3),n,nbasis)}
  else if(ii == 3) {a = matrix(rmt(nbasis*n,mean = rep(0,1),1,df=2),n,nbasis)}
  else if(ii == 4) {a = mvrnorm(n = n, mu=rep(1,nbasis), Sigma = diag(sqrt(5),nbasis), tol = 1e-6, empirical = FALSE)}
  else if(ii == 5) {a = mvrnorm(n = n, mu=rep(0,nbasis), Sigma = diag(sqrt(10),nbasis), tol = 1e-6, empirical = FALSE)}
  else if(ii == 6) {a = matrix(runif(nbasis*n,0,4),n,nbasis)}
  else if(ii == 7) {a = matrix(rnorm(nbasis*n,1.5,2),n,nbasis)}
  else if(ii == 8) {a = 0.5+matrix(rmt(nbasis*n,mean = rep(0,1),1,df=4),n,nbasis)}
  else if(ii == 9) {a = matrix(runif(nbasis*n,-4,4),n,nbasis)}
  else if(ii == 10) {a = matrix(rnorm(nbasis*n,0,6),n,nbasis)}
  else if(ii == 11) {a = matrix(rnorm(nbasis*n,1.5,15),n,nbasis)}
  else if(ii == 12) {a = matrix(rnorm(nbasis*n,0,15),n,nbasis)}
  else if(ii == 13) {a = matrix(rmt(nbasis*n,mean = rep(0,1),10,df=2),n,nbasis)}
  else{print("model does not exit")}
  return(a)
}



