#' @title Estimating the B-spline basis coefficients
#' in the scalar-on-function linear regression model
#' with roughness penalty with BIC using the subsample data selected
#' by the L_opt method

#' @description Estimating the B-spline basis coefficients
#' in the scalar-on-function linear regression model
#' using the subsample data selected by the L_opt method,
#' which applies the B-spline basis expansion and
#' roughness penalty with BIC.

#' @param N The design matrix.
#' @param N_norm A vector with \emph{i}th element is the norm of
#' the \emph{i}th row of the design matrix N.
#' @param yc The centered response vector.
#' @param r The subsample size to draw a random subsample with replacement.
#' @param ro The subsample size used to get the pilot estimator
#' of the basis coefficients.
#' @param lambda A sequence of non-negative smoothing parameters
#' for the roughness penalty.
#' @param V A square symmetric basis roughness
#' penalty matrix whose order is equal to the number of B-spline basis
#' functions used to expand the slop function.

#' @return
#' \item{c_Lopt} {A vector of the estimated B-spline basis coefficients using the
#' L-optimality motivated Algorithm 2 described in the reference Liu et al (2021).}
#' \item{lambda.lopt} {The optimal smoothing parameter selected by BIC under
#' the optimal subsample data using L_opt method.}

#' @references H.Liu, J.You, J.Cao (2021).
#' Optimal Subsampling in Massive Data with Functional Predictors.
#' @author Hua Liu, Jinhong You and Jiguo Cao


Lopt_BIC = function(N, N_norm, yc, r, r0, lambda, V )
{
  n = dim(N)[1]

  ###############################################
  #    Step 1: subsampel using the uniform      #
  #            sampling probabilities 1/n       #
  ###############################################
  index_uni0= sample(1:n,r0, replace = FALSE)
  N_uni0 = N[index_uni0,]
  y_uni0 = yc[index_uni0]

  # calculate c0
  A0 = t(N_uni0)%*%N_uni0
  B0 = t(N_uni0)%*%y_uni0
  # c0 = ginv(t(N_uni0)%*%N_uni0+lambda*V)%*%t(N_uni0)%*%y_uni0
  c0 = ginv(A0)%*%B0

  ###############################################
  #    Step 2: calculate the sampling           #
  #            probabilities p_Lopt             #
  ###############################################
  # N_norm = apply(N,1,norm,"2")
  # N_norm = rowNorms(N, "euclidean")
  res = yc - N%*%c0
  p_Lopt = abs(res)*N_norm/sum(abs(res)*N_norm)

  # subsample using p_Lopt
  index_Lopt= sample(1:n,r, prob =  p_Lopt,replace = TRUE)
  N_Lopt = N[index_Lopt,]
  y_Lopt = yc[index_Lopt]
  p_s_Lopt = p_Lopt[index_Lopt]
  W_Lopt = diag(1/(r*p_s_Lopt))


  ###############################################
  #    Step 3:  choosing the optimal lambda     #
  #        based on the optimal subsample data  #
  ###############################################
  nlambda   = length(lambda)
  bic.lopt = array(NA,nlambda)
  for (i in 1:nlambda)
  {
    bic.lopt[i] = BIC_Lopt(y_Lopt, N_Lopt, V, r, lambda[i], W_Lopt)
  }

  idx = which(bic.lopt == min(bic.lopt), arr.ind = TRUE)
  lambda.lopt = lambda[idx]

  ###############################################
  #    Step 4: estimate using the               #
  #            subsample data                   #
  ###############################################
  # estimate using the subsample data
  A_Lopt = t(N_Lopt)%*%W_Lopt%*%N_Lopt+lambda.lopt*V
  B_Lopt = t(N_Lopt)%*%W_Lopt%*%y_Lopt
  c_Lopt = ginv(A_Lopt)%*%B_Lopt

  return(list(c_Lopt = c_Lopt,lambda.lopt=lambda.lopt))
}
