# The estimator of c using the subsample data selected by
# uniform probability
#' @title The function to get the estimator of B-spline basis coefficient
#' using the subsample data selected by the uniform subsampling method
#' for the scalar-on-function generalized linear regression model
#' @description The function to get the estimator of basis coefficient
#' using the subsample data selected by the uniform subsampling method
#' for the scalar-on-function generalized linear regression model.

#' @param N The design matrix.
#' @param Y The response vector.
#' @param r The subsample size to draw a random subsample with replacement.
#' @param lambda A non-negative smoothing parameter
#' for the roughness penalty.
#' @param V A square symmetric basis roughness
#' penalty matrix whose order is equal to the number of B-spline basis
#' functions used to expand the slop function.
#' @param c0 The initial value used in the estimation.
#' @param family A description of the distribution of the response variable.


#' @return A vector of the estimated B-spline basis coefficients using the
#' uniform subsampling method for the scalar-on-function generalized linear regression model.

Unisub_FGLM = function(N, Y, r, lambda, V,c0,family)
{
  n = dim(N)[1]
  p = dim(N)[2]

  index_uni0= sample(1:n,r, replace = TRUE)
  N_uni0 = N[index_uni0,]
  Y_uni0 = Y[index_uni0]
  W_uni = rep(n/r,r)

  # calculate c0
  obj_unif <- optim(par = c0,fn = obj_FGLM,gr = gr_FGLM,
                    N=N_uni0,Y=Y_uni0,lambda=lambda,V=V,W=W_uni,
                    family = family,
                    method = c("BFGS"),
                    control=list(fnscale=-1))
  c_unif = obj_unif$par


  return(c_unif = c_unif)
}
