#' @title  Get the design matrix,
#' basis roughness penalty matrix
#' and basis function values matrix
#' @description The function to get the design matrix N,
#' the norm vector of each row of N,
#' the square symmetric basis roughness penalty matrix V,
#' and a matrix of basis function values basismat.
#'
#' @param X Input matrix; centered functional predictor;
#' each row is an observation vector;
#' each column corresponds to observed trajectory at design points.
#' @param K A positive integer; the inner knots used to expand the slop function.
#' @param d A positive integer that specifies the degree of the
#' B-spline basis used to expand the slop function.
#' @param domain An array of two numbers that specifies domain
#' for functional predictor.
#'
#'
#' @return
#' \item{N} {An n x (K+d+1) design matrix;
#' the \emph{(ij)}th element equals to the integral
#' of the \emph{i}th predictor and the \emph{j}th B-spline basis function.}
#' \item{V} {A (K+d+1) x (K+d+1) square symmetric basis roughness
#' penalty matrix whose order is equal to the number of B-spline basis
#' functions used to expand the slop function.}
#' \item{basismat} {An T x (K+d+1) matrix
#' of basis function values with rows corresponding to argument values
#' and columns to basis functions.}
#' \item{N_norm} {An n x 1 vector; the \emph{i}th element is the norm of
#' the \emph{i}th row of the design matrix N.}

#' @references H.Liu, J.You, J.Cao (2021).
#' Optimal Subsampling in Massive Data with Functional Predictors.
#' @author Hua Liu, Jinhong You and Jiguo Cao

compute.NV = function(X, K, d, domain)
{
  n = dim(X)[1]
  norder   = d+1 # order = degree +1
  nknots   = K+2 # the number of all knots = the number of inner knots + 2
  knots    = seq(domain[1],domain[2], length.out = nknots)
  nbasis   = nknots + norder - 2 # the number of basis = number of inner knots + order
  basis    = create.bspline.basis(knots,nbasis,norder)
  T   = dim(X)[2]
  tobs = seq(domain[1], domain[2], length.out = T)
  basismat = eval.basis(tobs, basis) # T x (K+d+1)
  V = eval.penalty(basis,int2Lfd(2))

  h   = (domain[2]-domain[1])/(T-1)
  cef = c(1, rep(c(4,2), (T-3)/2), 4, 1)
  u   = h/3*X%*%diag(cef)%*%basismat # n x nbasis
  u_norm = rowNorms(u, "euclidean")
  return(list(N=u,V = V,basismat = basismat,N_norm = u_norm))
}
