# The estimator of c using the subsample data selected by the leverage score
#' @title The function to get the estimator of B-spline basis coefficient
#' using the subsample data selected by the leverage score
#' @description The function to get the estimator of basis coefficient
#' using the subsample data selected by the leverage score

#' @param N The design matrix.
#' @param yc The centered response vector.
#' @param r The subsample size to draw a random subsample with replacement.
#' @param lambda A non-negative smoothing parameter
#' for the roughness penalty.
#' @param V A square symmetric basis roughness
#' penalty matrix whose order is equal to the number of B-spline basis
#' functions used to expand the slop function.

#' @return A vector of the estimated B-spline basis coefficients using the
#' leverage score.




Lscore = function(N, yc, r, lambda, V)
{
  n = dim(N)[1]

  ###############################################
  #    Step 1: calculate the leverage score     #
  ###############################################
  lscore = apply(svd(N)$u,1,norm,"2")^2/norm(svd(N)$u,"F")^2

  # subsample using the sampling probabilities leverage score
  index_LEV= sample(1:n,r,prob = lscore, replace = TRUE)
  N_LEV = N[index_LEV,]
  y_LEV = yc[index_LEV]
  p_s_LEV = lscore[index_LEV]

  # calculate c_LEV
  W_LEV = diag(1/(r*p_s_LEV))
  A_LEV = t(N_LEV)%*%W_LEV%*%N_LEV+lambda*V
  B_LEV = t(N_LEV)%*%W_LEV%*%y_LEV
  c_LEV = ginv(A_LEV)%*%B_LEV
  return(c = c_LEV)
}
