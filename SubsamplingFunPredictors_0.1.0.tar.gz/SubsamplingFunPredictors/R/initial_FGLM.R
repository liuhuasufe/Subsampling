# The function to get the initial value of c
#' @title The function to get the initial
#' estimator of B-spline basis coefficient for
#' the scalar-on-function generalized linear regression model

#' @description The function to get the initial estimator of
#' basis coefficient used in Algorithm 3 described in the
#' reference Liu et al (2021)
#' for the scalar-on-function generalized linear regression model.

#' @param Y The response variable vector.
#' @param N The design matrix.
#' @param family A description of the distribution of the response variable.

#' @return A vector of the estimated initial B-spline basis coefficients used
#' in Algorithm 3 described in the
#' reference Liu et al (2021).


#' @references H.Liu, J.You, J.Cao (2021).
#' Optimal Subsampling in Massive Data with Functional Predictors.
#' @author Hua Liu, Jinhong You and Jiguo Cao


initial_FGLM = function(Y,N,family)
{
  if(family == "Binomial"){obj0 <- glm(Y~-1+N,family = binomial(link = "logit"))}
  else if(family == "Possion") {obj0 <- glm(Y~-1+N,family = poisson(link = "log"))}
  else {print("family does not exit")}
  c0 <- obj0$coefficients
  return(c0)
}
