# function of generate data
#' @title The function of generate data in scalar-on-function
#' generalized linear regression
#'
#' @description This function uses B-spline basis to generate datasets
#' for the model
#' \deqn{E(Y)= \psi(\int_{a}^{b}X(t)\beta(t)dt) }
#' The true models for the slop function are described in
#' Liu et al (2021) in the reference.
#' @param n The nubmer of observations of the generated data.
#' @param nknots The nubmer of knots for the B-spline basis used to
#' generate the data.
#' @param norder The order for the B-spline basis used to
#' generate the data.
#' @param T The number of observed points.
#' @param domain An array of two numbers that specifies domain
#' for functional predictor.
#' @param aind A number selected from 1-13 indicating the
#' distribution used to generate the coefficient of B-spline basis.
#' See \link{a_fun} for more details.

#' @return A list of the following components
#' \item{X} {A matrix of the generated functional predictor.}
#' \item{y0} {The vector with the \emph{i}th element \eqn{\int_{a}^{b}x_i(t)\beta(t)dt}.}
#' @references H.Liu, J.You, J.Cao (2021).
#' Optimal Subsampling in Massive Data with Functional Predictors.
#' @author Hua Liu, Jinhong You and Jiguo Cao




FGLMR.data.generator.bsplines = function(n,nknots,norder,T,domain,aind)
{
  knots    = seq(domain[1],domain[2], length.out = nknots)
  nbasis   = nknots + norder - 2
  basis    = create.bspline.basis(knots,nbasis,norder)

  tobs = seq(domain[1],domain[2],length.out = T)
  basismat = eval.basis(tobs, basis)

  x = a_fun(n,nbasis,aind) %*% t(basismat)

  # betaeval = sqrt(2)*(sin(2*pi*tobs)+cos(2*pi*tobs))
  # betaeval = exp(-32*(tobs-0.5)^2)+2*tobs-1
  betaeval = sin(0.5*pi*tobs)

  # y0 the signals
  h   = (domain[2]-domain[1])/(T-1)
  cef = c(1, rep(c(4,2), (T-3)/2), 4, 1)
  # y0  = rep(NA,n)
  y0  = h/3*x%*%diag(cef)%*%betaeval
  # eps0= sd(y0)
  # y   = y0 + rnorm(n,mean = 0, sd = sigma)

  return(list(X=x,y0=y0))
}
